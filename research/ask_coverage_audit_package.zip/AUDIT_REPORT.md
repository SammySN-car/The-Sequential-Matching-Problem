﻿# Ask Coverage Audit — Greedy vs A+C Hard-Field Clarification

**Deliverable:** `research/ask_coverage_audit_package.zip` (this file: `AUDIT_REPORT.md`)
**Repo:** The-Sequential-Matching-Problem, commit `a8e26b35118cfa8e886a02f93984923e43ab64f6`, branch `main`
**Audit date:** 2026-10-07
**Mode:** READ-ONLY. No policy, config, simulator, evaluator, or research file was modified.
No evaluation runs, no new arms, no new outcome metrics were produced. Every number below
traces to a cited artifact in this package or to a shipped script in `audit_derived/`.

## How to read this report

Every claim carries one label:

- **[MEASURED]** — read directly from an existing artifact (path cited inline).
- **[CODE]** — read from frozen source (file:line cited; source included in this package).
- **[DERIVED]** — computed by the audit scripts shipped in `audit_derived/`
  (method and validation stated at first use).
- **[UNAVAILABLE]** — no artifact records it; obtaining it would require new experiments,
  which this audit explicitly did not run.

## Method (three read-only passes, all shipped)

1. `audit_derived/audit_analysis.py` — static world statistics via `kit.generate(...)`
   (world materialization only: no Simulator, no policy, no outcomes) + aggregation of
   official arm totals + decomposition of the existing Stage 1.5 probe artifact
   → `audit_derived/audit_digest.json`.
2. `audit_derived/ask_replay.py` — **ask-phase-only deterministic replay** of the greedy
   arm: 60 × (`observe` → `kit.baseline_asks` → `resolve_asks` → `advance([])`).
   No policy module is invoked, no matching occurs, no outcome metric is computed.
   - *Why this is faithful:* ask-eligibility is structurally independent of matching —
     a member with ≥1 missing HARD field can never have been introduced
     (`kit.py:206` + `available` at `kit.py:100`), so never busy/paused; introductions
     of other members do not affect its availability.
   - *Empirical validation:* replay totals equal the official `ask_cost` of **all 72
     greedy episodes exactly (72/72, zero mismatches)**. The daily figures in section A
     therefore carry the same status as official logs → `audit_derived/replay_digest.json`.
3. Probe decomposition (per-day sums/cross-tabs over the existing
   `research/round2_stage1_5/probe_seed101_run1.json`) — no re-run.
   The probe is included as **run1 only**: run1 sha256 == run2 sha256
   (`3897d631cc655ff433de7a6f0961ad7e6b920470f1e4df704487727299209c2c`; determinism also
   recorded in stage4 `x1_results.json` → `determinism.probe_run1_equals_run2`).

Nothing in this report is invented, estimated, or rounded beyond the stated precision.

---

## A. Ask budget usage (greedy arm)

**Nominal budget — [CODE]**
12 cost-units per decision day, reset daily: `ask_budget_remaining = 12 - ask_spent`
(`kit.py:107`), reset in `advance()` (`kit.py:189`); a constraints bundle costs 3
(`kit.py:113,121`) → at most 4 bundles/day. 60 decision days → nominal 720/episode
(`evaluate.py:85-97`); the 40 follow-up days run `advance([])` and issue no asks
(`evaluate.py:100-101`).

**Measured official totals — [MEASURED]** (`arm_greedy_seed107..118.json`, 72 episodes)

| statistic | value |
|---|---|
| ask_cost mean / median | **203.04** / 201 |
| min / max / sd | 165 / 258 / 24.97 |
| utilization vs 720 | **28.20 %** |
| per-decision-day mean | 3.384 |
| per-100-arrived mean | 101.52 (arrived = 200/ep) |
| bundles (cost/3) mean / total | 67.68 / 4 873 |
| all 72 costs divisible by 3? | yes (never a soft ask — see E) |
| Round-1 cross-check (results/greedy.json, seeds 101–103, n=18) | mean 206.67 |

**Daily shape — [DERIVED, replay validated 72/72]** (4 320 day-records = 72 eps × 60 days)

- Spend histogram: **12 → 1 103 days (25.5 %), 9 → 48, 6 → 82, 3 → 153, 0 → 2 934 (67.9 %)**.
  Median decision day = 0.
- Days 0–10: full 12 spent in **every** episode (72/72 each day). Taper starts day 11
  (68/72 full), day 12 → 61, day 13 → 47, day 14 → 38, day 15 → 31, day 16 → 26,
  day 17 → 20, day 18 → 13, day 19 → 4, day 20 → 3, day 21 → 0 full-spend episodes.
- **Last spend day: mean 19.4, min 17, max 21.** Days 22–59: spend = 0 in all 72 episodes.
- Eligible-pool mean over 72 eps: day0 **47.2** → day10 17.5 → day17 3.0 → day21 0.0.

**Reading:** greedy front-loads at the maximum rate and stops because the eligible pool
empties at day ~19–21. The 71.8 % nominal slack is *unspendable-by-eligibility*, not a
refusal to spend (connects to B and G). No official artifact logs greedy per-day spend;
the daily figures come from the validated ask-only replay shipped in this package.

---

## B. Missing / declined hard-field coverage

**Static world statistics — [MEASURED]** (`audit_derived/audit_analysis.py` over
`kit.generate(seed, 200, "evaluation", variant)`, 72 worlds = seeds 107–118 × 6 variants;
means per 200-member episode)

| quantity | all 72 | cold_start | other 5 variants (mean) |
|---|---|---|---|
| members with ≥1 HARD missing at generation (M0) | **134.72** (67.4 %) | 162.25 | ≈129.2 |
| … of which **declined-HARD** members | **67.04** | 83.83 | ≈63.7 |
| … **resolvable** (≥1 missing ∧ zero declined) | **67.68** | 78.42 | ≈65.5 |
| missing HARD fields (total) | 1 334.0 | 1 610.5 | ≈1 278 |
| … declined fields / not-yet-asked fields | 89.6 / 1 244.4 | 111.8 / 1 498.7 | ≈85 / ≈1 193 |

**Coverage achieved by greedy — [MEASURED join: official bundles × static worlds]**

- bundles asked = 67.68 mean = resolvable mean → **bundle share of resolvable = 1.000 in
  72/72 episodes (min = max = 1.0)**; bundles never exceed resolvable (0/72).
- members receiving ≥1 bundle = bundles (one bundle resolves a member permanently — E.7)
  → **every resolvable member was asked, in every episode**.

**End-of-run state — [DERIVED, replay validated]** (after 60 ask days)

- members still missing ≥1 HARD: mean **67.04** (min 52, max 95) — equal to the
  declined-HARD count exactly;
- members still missing **and not declined: 0 in 72/72 episodes** → zero resolvable
  members left unasked.

**The residual gap is structural — [CODE]**

- Declined HARD answers are never revealed by any ask (`kit.py:127`) and eligibility
  cannot return `feasible` while any HARD field is missing (`kit.py:70-87`) →
  **declined-HARD members are permanently non-introducible for every policy**
  (greedy or A+C). The ~67/episode unresolved members are a wall, not an ask-coverage miss.

**[UNAVAILABLE]** per-member dynamic resolution timelines in official runs — only
`ask_cost` totals are logged (`evaluate.py:80-115` computes episode metrics, not per-day
state).

---

## C. Ask → feasibility pipeline

**Code chain — [CODE]**

1. `kit.baseline_asks` selects bundles (`kit.py:205-208`);
2. `Simulator.resolve_asks` charges 3 (`kit.py:121`) and, for a `constraints` ask, copies
   truth into **all** HARD fields whose status is not `declined` (`kit.py:125-128`) —
   one bundle completes a non-declined member's HARD set;
3. `eligibility(a,b)` can then return `feasible` for pairs of completed members
   (`kit.py:70-87`);
4. `kit.baseline_match` builds candidate edges over feasible pairs (`kit.py:210-222`).

**Measured on the only existing instrument — [MEASURED]**
(Stage 1.5 probe, seed 101, 6 variants × 60 days, A+C trajectory; the baseline branch
runs on isolated per-day clones — `probe.py:157-183`; branch errors = 0, lost pairs = 0)

| quantity | value |
|---|---|
| baseline counterfactual cost (`cost_base`) | 2 226 (742 bundle-member-days) |
| newly feasible candidate pairs unlocked (`gains_base`) | **273** |
| cost per gained pair | **8.15** |
| days with counterfactual spend > 0 / those unlocking 0 pairs | 177 / **49** |
| `gains_base` by variant | 46 / 25 / 48 / 51 / 46 / 57 (dev/sparse/delayed/shift/drift/cold) |
| A+C's own gains (`gains_ac`) | **273 total** (per-variant 51/14/50/51/51/56) |
| soft-only branch gains (`gains_soft`) | **0** |
| constraints-only branch vs full A+C | `gains_con` = `gains_ac` per variant (51/14/50/51/51/56) |

Reading: on identical states, greedy-style constraint targeting and A+C unlock the **same
cumulative feasibility (273 = 273 total)** with a different daily/variant distribution
(per-day values differ on 124/360 days). Soft asks contribute exactly 0 feasibility
(structural: `eligibility` inspects HARD only — `kit.py:70-87`).

**Caveat — [MEASURED]:** the counterfactual branch *re-asks*: its 742 member-day-asks
exceed the distinct resolvable pool on seed-101 worlds (410 = 66+64+66+66+66+82), because
each day's clone is discarded (`probe.py:159-169`) while the A+C trajectory keeps its own
asks. Treat `cost_base`/`gains_base` as a **daily marginal instrument**, not distinct-member
totals; the equality of totals with the clean per-member `gains_ac` bounds (but does not
prove absence of) re-count effects.

**[UNAVAILABLE]** pair-level gains on **greedy's own trajectory**: official runs log only
`ask_cost` totals, and frontier reconstruction requires matching history — not derived here.

**[DERIVED]** coverage side: every resolvable member's HARD set was fully resolved in every
official episode (section B) → greedy's feasibility contribution from asks is maximal under
its target rules.

---

## D. Zero-selection days

**[UNAVAILABLE] for greedy's own trajectory.** No artifact logs per-day selections for the
greedy arm (arm files = episode totals; `results/greedy.json` = episode totals; stage2/3/4
diagnostics were run on A+C arms). Determining greedy's zero-selection days would require
new instrumented runs — explicitly not performed in this audit.

**[MEASURED, nearest evidence]** Stage 1.5 probe, seed 101, A+C states, 360 decision-days —
`greedy_n` = pairs `kit.baseline_match` would pick from the *same* state
(`probe.py:118-119, 256`):

- total 2 479, mean 6.9/day, **min = 2** → **days with greedy_n = 0: 0/360**;
- days with zero feasible candidates: **0/360** (`zero_candidate_days`);
- histogram {2:8, 3:33, 4:59, 5:25, 6:37, 7:38, 8:41, 9:50, 10:41, 11:16, 12:6, 13:5, 14:1}.

**[MEASURED context]** the zero-selection that *does* appear in the data belongs to the
A+C floor, not to feasibility:

- probe: 148/360 days had candidates but zero selections — **all** categorized
  `all_below_floor` (`probe overall.zero_selected_with_cand`, `zero_selected_categories`);
- stage4 `x1_results.json` (seed 101, per variant): zero-selection-with-candidates 17–47
  of 60 days (all `all_below_floor`); floor excluded **80.1–94.2 %** of feasible candidates;
  **83.5–94.1 %** of greedy's picks fall below the A+C floor (`greedy_blocked_share`).

**Honest boundary:** nearest evidence = 1 seed × A+C states. Greedy's own zero-selection
days remain unknown; nothing in any existing artifact shows a greedy zero-selection day.

---

## E. What the greedy ask policy actually does (spec answers)

All **[CODE]** with line refs; **[MEASURED]** confirmations where available.

- **E.1 Which asks:** only `constraints` bundles (cost 3) — `kit.py:208` emits a single
  `'field': 'constraints'`. *Never soft fields.* [MEASURED] 72/72 official greedy costs are
  divisible by 3; probe counterfactual `cost_base` ∈ {0,3,6,9,12}.
- **E.2 Target set:** `available` ∧ ≥1 HARD field `None` ∧ **zero declined HARD**
  (`kit.py:206-207`).
- **E.3 Ordering:** world-insertion order of `state['members']`
  (`eligible[:ask_budget_remaining//3]`, `kit.py:208`) — **not** oldest-arrival
  (`arrived_day` is never consulted), **not** blocked-based (no cross-member analysis),
  no soft priority.
- **E.4 Blocked trigger required?** **No.** The ask phase runs every decision day and
  `baseline_asks` has no notion of a blocked pair — it filters purely on eligibility
  (`policy.py:24` called each ask phase; `kit.py:205-208`). [MEASURED] every episode spent
  on days 0–21 regardless of matching state.
- **E.5 Daily cap:** `ask_budget_remaining // 3` → ≤4 bundles/day (`kit.py:107,189,208`).
  [MEASURED] max observed daily cost = 12; `kit.py:122` would raise on any excess.
- **E.6 Never soft:** yes (E.1). [MEASURED] probe branch soft asks = 0 by construction;
  official costs all %3==0.
- **E.7 ≤1 bundle per member ever:** after a bundle, a non-declined member has no missing
  HARD → ineligible; a declined member is excluded by the declined filter (`kit.py:206-207`).
  [MEASURED] bundles = distinct resolvable members (share 1.0, section B).
- **E.8 Who can remain unasked:** (a) declined-HARD members — permanently excluded by rule;
  (b) not-yet-arrived members — deferred to arrival (all arrive ≤ day 20; exhaustion ≤ 21 →
  0 missed, replay); (c) exited before their turn — **0 in 72/72** (replay end-state);
  (d) same-day cap when pool > 4 — day-0 pool mean 47.2 → some members wait ~1 day, but all
  are asked before exhaustion. **Net permanent non-coverage = declined members only
  (67.04/ep mean).**
- **E.9 A+C contrast — [CODE]:** `ac_asks` (`policy.py:334-411`) = tier1 blocked-flips
  (sort by −blocked, member_id) → tier1b progressive completion (sort by n_missing,
  member_id) → tier2 soft fields `relationship_goal`/`relationship_pace` (cost 1, sorted by
  feasible-partner count), budget-capped; any exception → `[]` (`policy.py:410-411`).
  Unlike greedy, tier1b only requires a `not_asked` HARD field (`policy.py:345-346`), so
  **declined-mixed members are askable by A+C** — but their declined fields still never
  resolve (`kit.py:127`).

---

## F. Greedy vs A+C (measured)

Same worlds for all arms: seeds 107–118 × 6 variants, 72 episodes/arm
(`research/round2_promotion_fresh_seeds/`).

| metric | A = greedy | B = A+C original | C = A+C floor/2 |
|---|---|---|---|
| ask_cost mean | **203.04** | 423.44 | 419.72 |
| utilization vs 720 | **28.2 %** | 58.8 % | 58.3 % |
| introductions (total) | **5 486** | 4 598 | 5 178 |
| mutual acceptances (total) | **780** | 733 | 773 |
| MSMI (total) | **71** | 54 | 58 |
| coverage mean | **0.3462** | 0.3313 | 0.3402 |
| primary (MSMI per 100 arrived) | **0.4931** | 0.3750 | 0.4028 |
| first-introduction wait mean | **6.72** | 11.99 | 10.40 |

**Paired contrasts — [MEASURED]** (`summary.json` → `paired_contrasts`, primary metric):

- C − B **+0.0278** CI [−0.118, +0.188]
- C − A **−0.0903** CI [−0.257, +0.069]
- B − A **−0.1181** CI [−0.340, +0.076]

On the primary metric the greedy arm's mean is the highest of the three (C−A CI includes 0,
so not significant at 95 %). The promotion decision — **READY / PROMOTE** for C
(`report.md:16,350`) — answered the *C vs B* question; it was not a greedy comparison.

**C-vs-B gates (context) — [MEASURED]:** volume C>B in 65/4/3 worlds = 90.28 % ≥ 80 % ✓
(CI +5.67…+10.60, mean Δ +8.06); mutual C vs B relative **+5.46 %** CI [−9.59, +24.56] ✓
vs the −8 % warning (`volume_confirmation`, `mutual_no_harm`).

**Ask-cost attribution — [CODE + MEASURED]:**

1. A+C spends ≈2× greedy on the same resolvable pool: probe shows A+C constraint spend
   371/ep (2 226/6) + soft ≈30/ep vs greedy 203/ep. Arithmetic on probe dev: A+C constraint
   member-asks = 118 vs M0 = 119, i.e. **≥52 of the 53 declined-mixed members were asked**
   (118 − 66 resolvable), each at cost 3 with **zero feasibility effect** (declined never
   resolves — `kit.py:127`), plus soft asks with measured feasibility gain 0.
2. Outcomes order exactly as floor severity predicts: intros no-floor (A) 5 486 >
   half-floor (C) 5 178 > full-floor (B) 4 598; stage4 `x1_results.json`: floor excludes
   80–94 % of feasible candidates, and 83.5–94.1 % of greedy's own picks sit below the
   A+C floor — i.e. B's extra asks build feasibility the floor then discards.
3. **Confound — do not read this table as a pure ask effect:** arms differ simultaneously
   in asks *and* matcher (greedy `baseline_match` vs model `ac_match`) *and* floor. The probe
   isolates asks on identical states: cumulative feasibility gains are equal (273 = 273).
4. Round-1 cross-check: greedy seeds 101–103 mean cost 206.67 (n=18) — consistent across
   seed sets.

---

## G. Hypothesis assessment

**Reconstructed hypothesis H-G** (the original wording is not stored in this repo; if your
brief's wording differs materially, re-scope this verdict):
*"Greedy leaves a large share of the daily ask budget unused → hard-field coverage is
incomplete → feasible pairs/matches are lost; spending the remainder (e.g. oldest-first)
would recover them."*

### Verdict: NOT SUPPORTED

1. **[DERIVED, validated 72/72]** the unused budget is an *empty pool*, not a paused
   policy: eligible pool mean = 0 from day 21; last spend day ≤ 21 in every episode;
   days 22–59 show spend = 0 while eligible = 0.
2. **[MEASURED, 72/72]** share of resolvable members asked = 1.000; resolvable-unasked at
   end = 0 in every episode.
3. **[CODE]** the only remaining missing members (67.04/ep) carry declined HARD answers,
   which no ask can ever reveal (`kit.py:127`) and which block feasibility permanently
   (`kit.py:70-87`) — budget spent on them is feasibility-neutral by construction.
4. **[MEASURED]** the other place leftover budget could go — soft asks — unlocks exactly 0
   feasibility (probe `gains_soft` = 0; `gains_con` = `gains_ac`).
5. **[MEASURED]** on the only marginal instrument that exists (probe counterfactual),
   late-day marginal gains collapse (49 of 177 spend-days unlocked 0 pairs; all 183
   full-spend days cluster in the early episode).

**Caveats:** hypothesis wording reconstructed above; probe = 1 seed with the re-ask caveat
(section C); greedy's daily shape comes from the validated replay rather than official logs.

---

## H. G+ experiment verdict

**Reconstructed G+:** *"let greedy spend its remaining daily budget on oldest-first
hard-constraint asks beyond its normal targeting."*

### Verdict: DO NOT RUN G+

- **The intervention targets an empty set.** After normal targeting there are no eligible
  targets left in any official episode (share = 1.0; pool = 0 from day 21) → expected added
  spend ≈ 0. If G+ ignores the declined filter, all spend flows to declined-mixed members
  with provably 0 feasibility gain (`kit.py:127`; E.2/E.8) — a measured ∞ cost-per-gain.
- **The measured walls are elsewhere:** (i) declined HARD, 67.04/ep, unfixable by asks
  (question B); (ii) the A+C floor, excluding 80–94 % of feasible candidates (questions
  D/F). G+ varies neither.
- **Not INSUFFICIENT EVIDENCE:** greedy's own daily trajectory is established (validated
  replay 72/72 + official totals), eligibility/declined mechanics are code-verified, and
  end-state coverage is measured directly. The previously-open gap ("no official greedy
  per-day logs") is closed by a validated derivation rather than a new experiment.
- **Adjacent but out of scope:** a soft-ask augmentation for greedy's matcher quality is
  *not* G+ (feasibility gain measured 0; matching-quality effect untested here). Running it
  would be a new experiment requiring its own design and gates.
- If your G+ wording instead targeted the declined wall ("ask declined members anyway"),
  the verdict is unchanged: **DO NOT RUN** — feasibility-neutral by construction
  (`kit.py:127`, `kit.py:70-87`).

---

## Appendix — package, provenance, integrity

See `AUDIT_MANIFEST.txt` for per-file SHA-256, sizes, roles, packaging timestamp,
git commit/branch, and the frozen-file integrity check performed at packaging time.

- Frozen files verified unchanged at packaging: `policy.py`, `policy_ac.py`, `kit.py`,
  `evaluate.py`, `organise.py`, `Dockerfile` (hashes recorded in the manifest).
- Git provenance recorded in the manifest (commit `a8e26b35…`, branch `main`, status).
- Probe: run1 only (sha256 == run2; determinism also in stage4 `x1_results.json`).
- Rerunnable read-only scripts: `audit_derived/audit_analysis.py`,
  `audit_derived/ask_replay.py` (+ their output digests).
- This report distinguishes measured facts from inference throughout; no statistic was
  fabricated, and no experiment was run beyond the deterministic derivations described in
  *Method*.
