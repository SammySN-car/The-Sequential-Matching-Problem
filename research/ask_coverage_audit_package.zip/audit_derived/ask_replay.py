﻿import json, sys, statistics
from pathlib import Path
from collections import Counter
REPO = Path(r"C:\Users\samar\Downloads\New folder (11)\The-Sequential-Matching-Problem")
sys.path.insert(0, str(REPO))
import kit

VARIANTS = ["development", "sparse", "delayed", "shift", "drift", "cold_start"]
SEEDS = list(range(107, 119))

def replay(seed, variant):
    """Ask-phase-only deterministic replay of the greedy arm.
    Faithful because ask-eligible members (>=1 missing HARD) can never be
    introduced, hence never busy/paused; matching cannot affect asks.
    No policy invocation, no matching, no outcomes."""
    w = kit.generate(seed, 200, "evaluation", variant)
    sim = kit.Simulator(w)
    daily = []
    for _ in range(60):
        state = sim.observe()
        elig = sum(1 for m in state["members"] if m["available"]
                   and any(m["fields"][k] is None for k in kit.HARD)
                   and not any(m["field_status"][k] == "declined" for k in kit.HARD))
        miss = sum(1 for m in state["members"]
                   if any(m["fields"][k] is None for k in kit.HARD))
        asks = kit.baseline_asks(state)
        sim.resolve_asks(asks)
        cost = sum(3 if a["field"] == "constraints" else 1 for a in asks)
        daily.append((sim.day, cost, len(asks), elig, miss))
        sim.advance([])          # official follow-up idiom: no introductions, exits+day proceed
    total = sum(d for _, d, _, _, _ in daily)
    return total, daily

# ---- validation against official arm totals + per-day aggregation ----
official = {}
for seed in SEEDS:
    d = json.loads((REPO/f"research/round2_promotion_fresh_seeds/arm_greedy_seed{seed}.json").read_text(encoding="utf-8"))
    for e in d["episodes"]:
        official[(seed, e["variant"])] = e["ask_cost"]

mismatch, spend_hist, day_spend = Counter(), Counter(), {d: Counter() for d in range(60)}
exhaust_days, end_missing, end_declined, end_miss_nondeclined = [], [], [], []
elig_curve = {d: [] for d in range(60)}
all_daily_costs = []
for seed in SEEDS:
    for v in VARIANTS:
        total, daily = replay(seed, v)
        if total != official[(seed, v)]:
            mismatch[(seed, v)] = (total, official[(seed, v)])
        last_spend = max((d for d, c, _, _, _ in daily if c > 0), default=-1)
        exhaust_days.append(last_spend)
        for d, c, n, elig, miss in daily:
            spend_hist[c] += 1
            day_spend[d][c] += 1
            all_daily_costs.append(c)
            elig_curve[d].append(elig)
        # end-state (after 60 ask days): members still missing HARD
        w = kit.generate(seed, 200, "evaluation", variant := v)
        # recompute end state from a fresh replay's final observe
        sim = kit.Simulator(w)
        for _ in range(60):
            sim.resolve_asks(kit.baseline_asks(sim.observe()))
            sim.advance([])
        fin = sim.observe()["members"]
        em = [m for m in fin if any(m["fields"][k] is None for k in kit.HARD)]
        end_missing.append(len(em))
        end_declined.append(sum(1 for m in em if any(
            m["field_status"][k] == "declined" for k in kit.HARD)))
        end_miss_nondeclined.append(sum(1 for m in em if not any(
            m["field_status"][k] == "declined" for k in kit.HARD)))

print("VALIDATION mismatches (replay vs official):", dict(mismatch) or "NONE — 72/72 exact")
print("spend histogram over 4320 day-records:", dict(sorted(spend_hist.items())))
print("mean cost/day:", round(statistics.mean(all_daily_costs), 3))
print("median:", statistics.median(all_daily_costs))
print("last-spend-day: mean", round(statistics.mean(exhaust_days), 1),
      "min", min(exhaust_days), "max", max(exhaust_days))
print("end-state missing: mean", round(statistics.mean(end_missing), 2),
      "min", min(end_missing), "max", max(end_missing))
print("end-state declined among missing: mean", round(statistics.mean(end_declined), 2))
print("end-state missing WITHOUT declined (missed resolvable):",
      dict(Counter(end_miss_nondeclined)))
print("\nmean eligible pool by day (first 30):",
      [round(statistics.mean(elig_curve[d]), 1) for d in range(30)])
print("mean spend by day (first 30):",
      [round(statistics.mean([c for d2, c, _, _, _ in [] ] or []), 1) for d in []] or
      [round(sum(c*n for c, n in day_spend[d].items())/72, 2) for d in range(30)])
print("spend-12 days by day idx (first 30):", [day_spend[d][12] for d in range(30)])

json.dump({"mismatch": {str(k): v for k, v in mismatch.items()},
           "spend_hist": dict(sorted(spend_hist.items())),
           "exhaust_days": exhaust_days,
           "end_missing": end_missing, "end_declined": end_declined,
           "end_miss_nondeclined": end_miss_nondeclined,
           "mean_cost_by_day": [round(sum(c*n for c, n in day_spend[d].items())/72, 3) for d in range(60)],
           "elig_by_day": [round(statistics.mean(elig_curve[d]), 2) for d in range(60)],
           "full12_by_day": [day_spend[d][12] for d in range(60)]},
          open(r"C:\Users\samar\AppData\Local\Temp\opencode\replay_digest.json", "w"), indent=1)
print("WROTE replay_digest.json")
