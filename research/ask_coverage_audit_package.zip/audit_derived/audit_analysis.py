﻿import json, sys, statistics, hashlib
from pathlib import Path
from collections import Counter

REPO = Path(r"C:\Users\samar\Downloads\New folder (11)\The-Sequential-Matching-Problem")
sys.path.insert(0, str(REPO))
import kit

VARIANTS = ["development", "sparse", "delayed", "shift", "drift", "cold_start"]
SEEDS = list(range(107, 119))
OUT = {}

# ---------- 1. Static world stats (kit.generate only; no simulator, no policy) ----------
def world_stats(seed, variant):
    w = kit.generate(seed, 200, "evaluation", variant)
    s = dict(complete=0, m0=0, declined_hard=0, resolvable=0,
             missing_hard_fields=0, declined_hard_fields=0, notasked_hard_fields=0,
             arrived0_with_missing=0, exited_ever=0)
    for m in w["members"]:
        miss = [k for k in kit.HARD if m["fields"][k] is None]
        decl = [k for k in kit.HARD if m["field_status"][k] == "declined"]
        na = [k for k in kit.HARD if m["field_status"][k] == "not_asked"]
        s["missing_hard_fields"] += len(miss)
        s["declined_hard_fields"] += len(decl)
        s["notasked_hard_fields"] += len(na)
        if m["exit_day"] is not None:
            s["exited_ever"] += 1
        if not miss:
            s["complete"] += 1
        else:
            s["m0"] += 1
            if m["arrived_day"] == 0:
                s["arrived0_with_missing"] += 1
            if decl:
                s["declined_hard"] += 1
            else:
                s["resolvable"] += 1
    return s

static = {}
for seed in SEEDS + [101]:
    for v in VARIANTS:
        static[(seed, v)] = world_stats(seed, v)
print("static worlds generated:", len(static))

def agg_static(seed_list):
    keys = ["complete", "m0", "declined_hard", "resolvable", "missing_hard_fields",
            "declined_hard_fields", "notasked_hard_fields", "arrived0_with_missing", "exited_ever"]
    per_variant = {}
    for v in VARIANTS:
        rows = [static[(s, v)] for s in seed_list]
        per_variant[v] = {k: round(statistics.mean(r[k] for r in rows), 2) for k in keys}
    all_rows = [static[(s, v)] for s in seed_list for v in VARIANTS]
    per_variant["ALL_mean"] = {k: round(statistics.mean(r[k] for r in all_rows), 2) for k in keys}
    return per_variant

OUT["static_per_variant_means_72worlds"] = agg_static(SEEDS)
OUT["static_per_variant_means_seed101"] = agg_static([101])

# ---------- 2. Official arm episode stats ----------
def load_arm(path):
    d = json.loads(path.read_text(encoding="utf-8"))
    return d["episodes"]

def arm_stats(episodes):
    costs = [e["ask_cost"] for e in episodes]
    not_div3 = [c for c in costs if c % 3 != 0]
    waits = [w for e in episodes for w in e.get("first_introduction_wait_days", [])]
    return dict(
        n=len(episodes),
        ask_cost_mean=round(statistics.mean(costs), 2),
        ask_cost_median=statistics.median(costs),
        ask_cost_min=min(costs), ask_cost_max=max(costs),
        ask_cost_stdev=round(statistics.stdev(costs), 2) if len(costs) > 1 else None,
        not_divisible_by_3=not_div3,
        bundles_mean=round(statistics.mean(costs) / 3, 2),
        utilization_vs_720=round(100 * statistics.mean(costs) / 720, 2),
        per_day_mean=round(statistics.mean(costs) / 60, 3),
        per_100_arrived_mean=round(statistics.mean(costs) / 2, 3),
        coverage_mean=round(statistics.mean(e["coverage"] for e in episodes), 4),
        assignments_total=sum(e["assignments"] for e in episodes),
        mutual_total=sum(e["mutual_acceptances"] for e in episodes),
        msmi_total=sum(e["mutual_second_meeting_intention"] for e in episodes),
        ask_cost_total=sum(costs),
        wait_mean=round(statistics.mean(waits), 3) if waits else None,
        wait_n=len(waits),
    )

arms = {}
for arm in ("greedy", "original", "floorhalf"):
    eps = []
    for seed in SEEDS:
        eps += load_arm(REPO / "research/round2_promotion_fresh_seeds" / f"arm_{arm}_seed{seed}.json")
    arms[arm] = eps
OUT["arm_stats"] = {a: arm_stats(e) for a, e in arms.items()}

# per-variant greedy ask stats
gv = {}
for v in VARIANTS:
    eps = [e for e in arms["greedy"] if e["variant"] == v]
    costs = [e["ask_cost"] for e in eps]
    gv[v] = dict(ask_cost_mean=round(statistics.mean(costs), 2),
                 ask_cost_min=min(costs), ask_cost_max=max(costs),
                 bundles_mean=round(statistics.mean(costs) / 3, 2))
OUT["greedy_ask_by_variant"] = gv

# ---------- 3. Join greedy episodes with static worlds (section B) ----------
join_rows = []
for e in arms["greedy"]:
    st = static[(e["seed"], e["variant"])]
    bundles = e["ask_cost"] / 3
    join_rows.append(dict(
        seed=e["seed"], variant=e["variant"],
        m0=st["m0"], declined_hard=st["declined_hard"], resolvable=st["resolvable"],
        bundles=bundles, unresolved_at_end=st["m0"] - bundles,
        bundle_share_of_resolvable=round(bundles / st["resolvable"], 4),
        exceeds_resolvable=bundles > st["resolvable"],
    ))
OUT["join_greedy_static"] = dict(
    n=len(join_rows),
    exceeds_resolvable_any=any(r["exceeds_resolvable"] for r in join_rows),
    unresolved_mean=round(statistics.mean(r["unresolved_at_end"] for r in join_rows), 2),
    unresolved_min=min(r["unresolved_at_end"] for r in join_rows),
    unresolved_max=max(r["unresolved_at_end"] for r in join_rows),
    bundle_share_mean=round(statistics.mean(r["bundle_share_of_resolvable"] for r in join_rows), 4),
    bundle_share_min=min(r["bundle_share_of_resolvable"] for r in join_rows),
    bundle_share_max=max(r["bundle_share_of_resolvable"] for r in join_rows),
    bundles_mean=round(statistics.mean(r["bundles"] for r in join_rows), 2),
    m0_mean=round(statistics.mean(r["m0"] for r in join_rows), 2),
    resolvable_mean=round(statistics.mean(r["resolvable"] for r in join_rows), 2),
    declined_mean=round(statistics.mean(r["declined_hard"] for r in join_rows), 2),
)
# per-variant join means
jv = {}
for v in VARIANTS:
    rows = [r for r in join_rows if r["variant"] == v]
    jv[v] = dict(
        m0_mean=round(statistics.mean(r["m0"] for r in rows), 2),
        resolvable_mean=round(statistics.mean(r["resolvable"] for r in rows), 2),
        declined_mean=round(statistics.mean(r["declined_hard"] for r in rows), 2),
        bundles_mean=round(statistics.mean(r["bundles"] for r in rows), 2),
        unresolved_mean=round(statistics.mean(r["unresolved_at_end"] for r in rows), 2),
        share_mean=round(statistics.mean(r["bundle_share_of_resolvable"] for r in rows), 4),
    )
OUT["join_by_variant"] = jv

# ---------- 4. Probe daily distributions (seed101 AC states) ----------
pb = json.loads((REPO / "research/round2_stage1_5/probe_seed101_run1.json").read_text(encoding="utf-8"))
cb_hist, cac_hist, gains_hist, per_variant_gains = Counter(), Counter(), Counter(), {}
join_days = dict(total=0, unused_budget=0, greedy_n_zero=0, unused_and_greedy_zero=0,
                 unused_and_cand_zero=0, cand_zero=0, gains_day_pos=0,
                 unused_and_gains_pos=0, soft_ask_days=0, full_spend_days=0)
gain_days_by_variant = {}
for v in VARIANTS:
    pv = 0
    for d in pb["episodes"][v]["days"]:
        a, mt = d["ask"], d["match"]
        join_days["total"] += 1
        cb_hist[a["cost_base"]] += 1
        cac_hist[a["cost_ac"]] += 1
        if a["gains_base"] > 0:
            gains_hist[a["gains_base"]] += 1
            join_days["gains_day_pos"] += 1
            pv += a["gains_base"]
        if a["cost_base"] < 12:
            join_days["unused_budget"] += 1
            if a["gains_base"] > 0:
                join_days["unused_and_gains_pos"] += 1
        else:
            join_days["full_spend_days"] += 1
        if a["cost_ac_soft"] > 0:
            join_days["soft_ask_days"] += 1
        if mt["greedy_n"] == 0:
            join_days["greedy_n_zero"] += 1
            if a["cost_base"] < 12:
                join_days["unused_and_greedy_zero"] += 1
        if mt["n_cand"] == 0:
            join_days["cand_zero"] += 1
            if a["cost_base"] < 12:
                join_days["unused_and_cand_zero"] += 1
    per_variant_gains[v] = pv
OUT["probe_daily"] = dict(
    cost_base_hist=dict(sorted(cb_hist.items())),
    cost_ac_hist=dict(sorted(cac_hist.items())),
    gains_base_pos_day_hist=dict(sorted(gains_hist.items())),
    join=join_days,
    gains_base_by_variant=per_variant_gains,
    gains_base_total=sum(per_variant_gains.values()),
    bundles_base_total=pb["overall"]["ask_base_members"],
    gains_per_bundle=round(pb["overall"]["gains_base"] / pb["overall"]["ask_base_members"], 4),
    overall_subset={k: pb["overall"][k] for k in (
        "ask_cost_base_counterfactual", "ask_cost_ac", "ask_cost_ac_con", "ask_cost_ac_soft",
        "gains_base", "gains_ac", "gains_con", "gains_soft", "lost_ac", "lost_base",
        "ask_base_members", "ask_con_members", "ask_overlap_members",
        "cost_per_gain_base", "cost_per_gain_ac", "cand_total", "zero_candidate_days",
        "zero_selected_with_cand", "greedy_n", "floor_removed_pct")},
)

# greedy_n distribution
gns = Counter()
for v in VARIANTS:
    for d in pb["episodes"][v]["days"]:
        gns[d["match"]["greedy_n"]] += 1
OUT["probe_greedy_n_hist"] = dict(sorted(gns.items()))

# ---------- 5. Round-1 greedy (seeds 101-103) episode stats for cross-check ----------
r1 = json.loads((REPO / "results/greedy.json").read_text(encoding="utf-8"))
r1_eps = r1["episodes"] if isinstance(r1, dict) and "episodes" in r1 else []
if r1_eps:
    OUT["round1_greedy"] = arm_stats(r1_eps)

print(json.dumps(OUT, indent=1, sort_keys=False))
Path(r"C:\Users\samar\AppData\Local\Temp\opencode\audit_digest.json").write_text(
    json.dumps(OUT, indent=1), encoding="utf-8")
print("WROTE audit_digest.json")
